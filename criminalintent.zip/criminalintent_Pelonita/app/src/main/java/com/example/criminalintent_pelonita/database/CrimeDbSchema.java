package com.example.criminalintent_pelonita.database;

public class CrimeDbSchema {
    public static final class CrimeTable{
        //14.1
        public static final String NAME = "crimes";
        //14.2
        public static final class Cols{
            public static final String UUID = "uuid";
            public static final String TITLE = "title";
            public static final String DATE = "date";
            public static final String SOLVED = "solved";
        }//14.2
    }//14.1
}
