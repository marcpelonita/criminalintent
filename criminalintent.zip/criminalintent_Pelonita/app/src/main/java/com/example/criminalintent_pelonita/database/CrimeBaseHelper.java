package com.example.criminalintent_pelonita.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.criminalintent_pelonita.database.CrimeDbSchema.CrimeTable;

//14.3
public class CrimeBaseHelper extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "crimeBase.db";

    public CrimeBaseHelper(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        //14.5                                     //14.6
        db.execSQL("create table  " + CrimeTable.NAME + "(" +
                " _id integer primary key autoincrement, "+
                CrimeTable.Cols.UUID + "," +
                CrimeTable.Cols.TITLE + ","+
                CrimeTable.Cols.DATE + "," +
                CrimeTable.Cols.SOLVED +
                ")"//14.6
        );
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }
    //14.3
}
