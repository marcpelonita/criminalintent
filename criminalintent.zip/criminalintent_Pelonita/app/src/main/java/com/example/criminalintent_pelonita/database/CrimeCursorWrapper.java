package com.example.criminalintent_pelonita.database;

import android.database.Cursor;
import android.database.CursorWrapper;
import com.example.criminalintent_pelonita.database.CrimeDbSchema.CrimeTable;

import com.example.criminalintent_pelonita.Crime;

import java.util.Date;
import java.util.UUID;

//14.13
public class CrimeCursorWrapper extends CursorWrapper {
    public CrimeCursorWrapper(Cursor cursor){
        super(cursor);
    }
    //14.13

    //14.14
    public Crime getCrime(){
        String uuidString = getString(getColumnIndex(CrimeTable.Cols.UUID));
        String title = getString(getColumnIndex(CrimeTable.Cols.TITLE));
        long date = getLong(getColumnIndex(CrimeTable.Cols.DATE));
        int isSolved = getInt(getColumnIndex(CrimeTable.Cols.SOLVED));

        //14.16
        Crime crime = new Crime(UUID.fromString(uuidString));
        crime.setTitle(title);
        crime.setDate(new Date(date));
        crime.setSolved(isSolved !=0);

        return crime;//14.16
        //14.16 return null;
    }
    //14.14
}
