package com.example.criminalintent_pelonita;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.criminalintent_pelonita.database.CrimeCursorWrapper;
import com.example.criminalintent_pelonita.database.CrimeDbSchema.CrimeTable;
import com.example.criminalintent_pelonita.database.CrimeBaseHelper;
import com.example.criminalintent_pelonita.database.CrimeDbSchema;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CrimeLab {

    private static CrimeLab sCrimeLab;
    //14.7 private List<Crime> mCrimes;
    //14.4
    private Context mContext;
    private SQLiteDatabase mDatabase;
    //14.4
    public static CrimeLab get(Context context) {
        if (sCrimeLab == null) {
            sCrimeLab = new CrimeLab(context);
        }
        return sCrimeLab;
    }
    private CrimeLab(Context context) {
        //14.4
        mContext = context.getApplicationContext();
        mDatabase = new CrimeBaseHelper(mContext)
                .getWritableDatabase();
        //14.4
        //14.7 mCrimes = new ArrayList<>();
        //13.9 erase
        //for (int i = 0; i < 100; i++) {
            //Crime crime = new Crime();
            //crime.setTitle("Crime #" + i);
            //crime.setSolved(i % 2 == 0); // Every other one
            //mCrimes.add(crime);
        //}
        //13.9 erase
    }
    //13.8
    public void addCrime(Crime c){
       //14.7 mCrimes.add(c);

        //14.9
        ContentValues values = getContentValues(c);
        mDatabase.insert(CrimeTable.NAME, null,values);
        //14.9
    }
    //13.8
    public List<Crime> getCrimes() {
        //14.7 return mCrimes;
        //14.18 return new ArrayList<>();//14.7
        List<Crime> crimes = new ArrayList<>();

        CrimeCursorWrapper cursor = queryCrimes(null,null);

        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()){
                crimes.add(cursor.getCrime());
                cursor.moveToNext();
            }
        }finally {
            cursor.close();
        }
        return crimes;
        //14.18
    }
    public Crime getCrime(UUID id) {
        //14.7 for (Crime crime : mCrimes) {
           // if (crime.getId().equals(id)) {
               // return crime;
           // }
      //14.7  }
        //14.19 return null;
        //14.19
        CrimeCursorWrapper cursor = queryCrimes(
                CrimeTable.Cols.UUID + "= ?",
                new String[] { id.toString()}
        );
        try {
            if (cursor.getCount() == 0){
                return null;
            }
            cursor.moveToFirst();
            return cursor.getCrime();
        }finally {
            cursor.close();
        }
        //14.19
    }
    //14.10
    public void updateCrime(Crime crime){
        String uuiString = crime.getId().toString();
        ContentValues values = getContentValues(crime);

        mDatabase.update(CrimeTable.NAME, values,
                CrimeTable.Cols.UUID+ " = ?",
                new String[] { uuiString});
    }
    //14.10

    //14.12
    //14.17 private Cursor queryCrimes(String whereClause, String[] whereArgs){
    //14.7
    private CrimeCursorWrapper queryCrimes(String whereClause, String[] whereArgs){
        Cursor cursor = mDatabase.query(
                CrimeTable.NAME,
                null, //columns - null selects all columns
                whereClause,
                whereArgs,
                null, // groupBY
                null, // having
                null // orderBy
        );
        // 14.17 return cursor;
        return new CrimeCursorWrapper(cursor);
    }
    //14.12

    //14.8
    private static ContentValues getContentValues(Crime crime){
        ContentValues values = new ContentValues();
        values.put(CrimeTable.Cols.UUID, crime.getId().toString());
        values.put(CrimeTable.Cols.TITLE, crime.getTitle());
        values.put(CrimeTable.Cols.DATE, crime.getDate().getTime());
        values.put(CrimeTable.Cols.SOLVED, crime.isSolved() ? 1 : 0);

        return values;
    }
    //14.8

}
